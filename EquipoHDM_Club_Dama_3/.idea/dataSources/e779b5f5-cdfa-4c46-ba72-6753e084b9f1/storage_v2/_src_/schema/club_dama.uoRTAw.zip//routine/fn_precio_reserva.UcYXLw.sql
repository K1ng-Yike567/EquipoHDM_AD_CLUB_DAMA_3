create
    definer = root@localhost function fn_precio_reserva(minutos int) returns decimal(8, 2) deterministic
BEGIN
  DECLARE tramos INT;
  SET tramos = CEIL(minutos / 30);
  RETURN tramos * 6.00;
END;

