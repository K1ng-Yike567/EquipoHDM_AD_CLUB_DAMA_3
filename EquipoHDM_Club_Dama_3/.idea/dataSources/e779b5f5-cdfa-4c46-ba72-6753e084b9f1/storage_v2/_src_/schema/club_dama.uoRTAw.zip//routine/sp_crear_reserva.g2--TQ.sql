create
    definer = root@localhost procedure sp_crear_reserva(IN p_id_reserva varchar(36), IN p_id_socio varchar(36),
                                                        IN p_id_pista varchar(36), IN p_fecha date, IN p_hora_ini time,
                                                        IN p_duracion int)
BEGIN
    DECLARE v_disponible BOOLEAN;
    DECLARE v_fin TIME;
    DECLARE v_precio DECIMAL(8,2);

    IF p_duracion <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'La duración debe ser > 0';
    END IF;

    -- Comprobar pista operativa
    SELECT disponible INTO v_disponible
    FROM pistas WHERE id_pista = p_id_pista;
    IF v_disponible IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Pista inexistente';
    END IF;
    IF v_disponible = FALSE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Pista no operativa';
    END IF;

    -- Calcular fin
    SET v_fin = ADDTIME(p_hora_ini, SEC_TO_TIME(p_duracion * 60));

    -- Comprobar solape en misma fecha (intervalo cerrado-abierto)
    IF EXISTS (
        SELECT 1 FROM reservas r
        WHERE r.id_pista = p_id_pista
          AND r.fecha = p_fecha
          AND (
                (p_hora_ini < ADDTIME(r.hora_inicio, SEC_TO_TIME(r.duracion_min*60)))
                AND
                (v_fin > r.hora_inicio)
              )
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Solape de reservas en esa pista';
    END IF;

    -- Calcular precio (usa función opcional)
    SET v_precio = fn_precio_reserva(p_duracion);

    INSERT INTO reservas(id_reserva, id_socio, id_pista, fecha, hora_inicio, duracion_min, precio)
    VALUES (p_id_reserva, p_id_socio, p_id_pista, p_fecha, p_hora_ini, p_duracion, v_precio);
END;

